/**
 * Health Metrics Panel functionality
 * Handles design system health visualization and compliance tracking
 */

let lastComplianceCheck = 0;

/**
 * Initialize health metrics panel
 */
function initializeHealthMetrics() {
  console.log('🔍 Starting health metrics initialization...');
  
  // Auto-trigger compliance analysis on load
  setTimeout(() => {
    console.log('🔄 Triggering compliance calculation...');
    triggerComplianceCalculation();
  }, 1000);
  
  // Auto-trigger compliance analysis on user interaction
  document.addEventListener('click', throttle(() => {
    setTimeout(() => {
      triggerComplianceCalculation();
    }, 500);
  }, 2000));
  
  // Periodic refresh every 30 seconds
  setInterval(() => {
    triggerComplianceCalculation();
  }, 30000);
  
  console.log('📊 Health Metrics initialized');
}

/**
 * Trigger compliance calculation with throttling
 */
function triggerComplianceCalculation() {
  // Throttle compliance checks to avoid spam
  const now = Date.now();
  if (now - lastComplianceCheck < 2000) return; // Max once per 2 seconds
  
  lastComplianceCheck = now;
  
  // Request compliance analysis
  sendToPlugin({ type: 'calculate-compliance' });
}

/**
 * Update health metrics display
 * @param {Object|null} compliance - Compliance data or null to reset
 */
function updateHealthMetrics(compliance) {
  if (!elements.overallScore) return;
  
  if (compliance) {
    // Update metric values with animation
    if (elements.overallScore) {
      elements.overallScore.textContent = `${compliance.overall}%`;
      elements.overallScore.className = `metric-value ${getScoreClass(compliance.overall)}`;
    }
    
    if (elements.complianceRate) {
      elements.complianceRate.textContent = `${compliance.overall}%`;
      elements.complianceRate.className = `metric-value ${getScoreClass(compliance.overall)}`;
    }
    
    if (elements.componentUsage) {
      elements.componentUsage.textContent = `${compliance.breakdown.components.score}%`;
      elements.componentUsage.className = `metric-value ${getScoreClass(compliance.breakdown.components.score)}`;
    }
    
    if (elements.tokenAdoption) {
      const tokenScore = Math.round((compliance.breakdown.colors.score + compliance.breakdown.typography.score) / 2);
      elements.tokenAdoption.textContent = `${tokenScore}%`;
      elements.tokenAdoption.className = `metric-value ${getScoreClass(tokenScore)}`;
    }
  } else {
    // Reset to placeholder state
    [elements.overallScore, elements.complianceRate, elements.componentUsage, elements.tokenAdoption].forEach(el => {
      if (el) {
        el.textContent = '--';
        el.className = 'metric-value';
      }
    });
  }
}

/**
 * Update detailed component analysis
 * @param {Object} compliance - Compliance data
 * @param {number} selectionCount - Number of selected elements
 */
function updateComponentAnalysis(compliance, selectionCount) {
  const componentAnalysis = document.getElementById('componentAnalysis');
  if (!componentAnalysis) return;
  
  const breakdown = compliance.breakdown;
  const html = `
    <div class="analysis-summary">
      <div class="summary-stat">
        <span class="stat-label">Elements analyzed:</span>
        <span class="stat-value">${selectionCount}</span>
      </div>
    </div>
    
    <div class="breakdown-grid">
      <div class="breakdown-item">
        <div class="breakdown-label">Colors</div>
        <div class="breakdown-score ${getScoreClass(breakdown.colors.score)}">${breakdown.colors.score}%</div>
        <div class="breakdown-details">${breakdown.colors.compliantCount}/${breakdown.colors.totalCount} compliant</div>
      </div>
      
      <div class="breakdown-item">
        <div class="breakdown-label">Typography</div>
        <div class="breakdown-score ${getScoreClass(breakdown.typography.score)}">${breakdown.typography.score}%</div>
        <div class="breakdown-details">${breakdown.typography.compliantCount}/${breakdown.typography.totalCount} compliant</div>
      </div>
      
      <div class="breakdown-item">
        <div class="breakdown-label">Components</div>
        <div class="breakdown-score ${getScoreClass(breakdown.components.score)}">${breakdown.components.score}%</div>
        <div class="breakdown-details">${breakdown.components.compliantCount}/${breakdown.components.totalCount} compliant</div>
      </div>
      
      <div class="breakdown-item">
        <div class="breakdown-label">Spacing</div>
        <div class="breakdown-score ${getScoreClass(breakdown.spacing.score)}">${breakdown.spacing.score}%</div>
        <div class="breakdown-details">${breakdown.spacing.compliantCount}/${breakdown.spacing.totalCount} compliant</div>
      </div>
    </div>
  `;
  
  componentAnalysis.innerHTML = html;
}

/**
 * Update health recommendations
 * @param {Array} recommendations - Array of recommendation objects
 */
function updateRecommendations(recommendations) {
  if (!elements.healthRecommendations) return;
  
  if (recommendations && recommendations.length > 0) {
    const html = recommendations.slice(0, 3).map(rec => `
      <div class="recommendation-item ${rec.priority}">
        <div class="rec-priority">${rec.priority.toUpperCase()}</div>
        <div class="rec-category">${rec.category}</div>
        <div class="rec-description">${rec.description}</div>
        <div class="rec-action">${rec.action}</div>
      </div>
    `).join('');
    
    elements.healthRecommendations.innerHTML = html;
  } else {
    elements.healthRecommendations.innerHTML = `
      <div class="metric-row">
        <span class="metric-name">No recommendations at this time</span>
      </div>
    `;
  }
}

/**
 * Display compliance results
 * @param {Object} compliance - Compliance data
 * @param {number} selectionCount - Number of selected elements
 */
function displayComplianceResults(compliance, selectionCount) {
  console.log('📊 Displaying compliance results:', compliance);
  
  // Update overall score
  updateHealthMetrics(compliance);
  
  // Show detailed analysis if there's selection
  if (selectionCount > 0) {
    updateComponentAnalysis(compliance, selectionCount);
    updateRecommendations(compliance.recommendations);
  }
  
  // Update detailed metrics
  updateDetailedMetrics(compliance);
  
  // Update last updated timestamp
  const lastUpdated = document.getElementById('lastUpdated');
  if (lastUpdated) {
    lastUpdated.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
  }
}

/**
 * Update detailed metrics sections
 * @param {Object} compliance - Compliance data
 */
function updateDetailedMetrics(compliance) {
  if (!compliance) return;
  
  const breakdown = compliance.breakdown;
  
  // Update component metrics
  if (elements.standardComponents) {
    elements.standardComponents.textContent = breakdown.components.compliantCount;
    elements.standardComponents.className = `metric-score ${getMetricScoreClass(breakdown.components.score)}`;
  }
  
  if (elements.customComponents) {
    const customCount = breakdown.components.totalCount - breakdown.components.compliantCount;
    elements.customComponents.textContent = customCount;
    elements.customComponents.className = `metric-score ${customCount > 0 ? 'medium' : 'high'}`;
  }
  
  if (elements.topComponent) {
    elements.topComponent.textContent = compliance.topComponents?.[0]?.name || 'Button';
    elements.topComponent.className = 'metric-score high';
  }
  
  // Update token metrics
  if (elements.colorTokens) {
    elements.colorTokens.textContent = `${breakdown.colors.score}%`;
    elements.colorTokens.className = `metric-score ${getMetricScoreClass(breakdown.colors.score)}`;
  }
  
  if (elements.typographyTokens) {
    elements.typographyTokens.textContent = `${breakdown.typography.score}%`;
    elements.typographyTokens.className = `metric-score ${getMetricScoreClass(breakdown.typography.score)}`;
  }
  
  if (elements.spacingTokens) {
    elements.spacingTokens.textContent = `${breakdown.spacing.score}%`;
    elements.spacingTokens.className = `metric-score ${getMetricScoreClass(breakdown.spacing.score)}`;
  }
}

/**
 * Get metric score class for styling
 * @param {number} score - Score from 0-100
 * @returns {string} CSS class name
 */
function getMetricScoreClass(score) {
  if (score >= 90) return 'high';
  if (score >= 70) return 'medium';
  return 'low';
}

/**
 * Show compliance error
 * @param {string} message - Error message
 */
function showComplianceError(message) {
  const componentAnalysis = document.getElementById('componentAnalysis');
  if (componentAnalysis) {
    componentAnalysis.innerHTML = `
      <div class="placeholder-text error">
        <span>⚠️ ${message}</span>
      </div>
    `;
  }
  
  if (elements.healthRecommendations) {
    elements.healthRecommendations.innerHTML = `
      <div class="placeholder-text">
        Select frames or components to get recommendations
      </div>
    `;
  }
}

/**
 * Handle no design system detected
 */
function handleNoDesignSystem() {
  updateHealthMetrics(null);
  
  if (elements.healthRecommendations) {
    elements.healthRecommendations.innerHTML = `
      <div class="metric-row">
        <span class="metric-name">No design system detected</span>
      </div>
    `;
  }
}