/**
 * Context Preview Component
 * 
 * A reusable component for displaying context data before LLM submission
 * Includes MCP data, screenshots, tech stack analysis, and context metrics
 */

class ContextPreview {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      showAdvancedMetrics: options.showAdvancedMetrics ?? true,
      enableEditing: options.enableEditing ?? true,
      showTokenCount: options.showTokenCount ?? true,
      collapsible: options.collapsible ?? true,
      ...options
    };
    
    this.contextData = null;
    this.onDataChange = options.onDataChange || (() => {});
    this.onSubmit = options.onSubmit || (() => {});
    
    this.init();
  }

  init() {
    this.container.className = 'context-preview-container';
    this.render();
    this.bindEvents();
  }

  render() {
    this.container.innerHTML = `
      <div class="context-preview">
        <div class="context-preview-header">
          <div class="header-left">
            <h3 class="context-preview-title">
              🔍 Context Preview
              <span class="context-preview-badge">Review Before Sending</span>
            </h3>
            <p class="context-preview-subtitle">Review what will be sent to the AI for processing</p>
          </div>
          <div class="header-right">
            ${this.options.collapsible ? `
              <button class="collapse-btn" type="button">
                <span class="collapse-icon">▼</span>
              </button>
            ` : ''}
          </div>
        </div>

        <div class="context-preview-body">
          <div class="context-sections">
            <!-- Tech Stack Section -->
            <div class="context-section" data-section="techstack">
              <div class="section-header">
                <div class="section-header-left">
                  <h4 class="section-title">🛠️ Tech Stack Analysis</h4>
                  <div class="section-status" id="techstack-status">
                    <span class="status-indicator">⚪</span>
                    <span class="status-text">Not analyzed</span>
                  </div>
                </div>
                ${this.options.enableEditing ? `
                  <div class="section-actions">
                    <button class="edit-btn" data-section="techstack">Edit</button>
                    <button class="remove-btn" data-section="techstack">Remove</button>
                  </div>
                ` : ''}
              </div>
              <div class="section-content" id="techstack-content">
                <div class="empty-state">
                  <span class="empty-icon">📝</span>
                  <p>Enter your tech stack description to see analysis here</p>
                </div>
              </div>
            </div>

            <!-- Screenshot Section -->
            <div class="context-section" data-section="screenshot">
              <div class="section-header">
                <div class="section-header-left">
                  <h4 class="section-title">📸 Visual Context</h4>
                  <div class="section-status" id="screenshot-status">
                    <span class="status-indicator">⚪</span>
                    <span class="status-text">No screenshot</span>
                  </div>
                </div>
                ${this.options.enableEditing ? `
                  <div class="section-actions">
                    <button class="capture-btn" data-section="screenshot">Capture</button>
                    <button class="remove-btn" data-section="screenshot">Remove</button>
                  </div>
                ` : ''}
              </div>
              <div class="section-content" id="screenshot-content">
                <div class="empty-state">
                  <span class="empty-icon">🖼️</span>
                  <p>No visual context available</p>
                  <small>Screenshots help AI understand design layouts and requirements</small>
                </div>
              </div>
            </div>

            <!-- MCP Data Section -->
            <div class="context-section" data-section="mcpdata">
              <div class="section-header">
                <div class="section-header-left">
                  <h4 class="section-title">🔗 MCP Server Data</h4>
                  <div class="section-status" id="mcpdata-status">
                    <span class="status-indicator">⚪</span>
                    <span class="status-text">No MCP data</span>
                  </div>
                </div>
                ${this.options.enableEditing ? `
                  <div class="section-actions">
                    <button class="refresh-btn" data-section="mcpdata">Refresh</button>
                    <button class="remove-btn" data-section="mcpdata">Remove</button>
                  </div>
                ` : ''}
              </div>
              <div class="section-content" id="mcpdata-content">
                <div class="empty-state">
                  <span class="empty-icon">🤖</span>
                  <p>MCP server not connected</p>
                  <small>Enable enhanced analysis with Model Context Protocol</small>
                </div>
              </div>
            </div>

            <!-- Design System Section -->
            <div class="context-section" data-section="designsystem">
              <div class="section-header">
                <div class="section-header-left">
                  <h4 class="section-title">🎨 Design System</h4>
                  <div class="section-status" id="designsystem-status">
                    <span class="status-indicator">⚪</span>
                    <span class="status-text">Not detected</span>
                  </div>
                </div>
                ${this.options.enableEditing ? `
                  <div class="section-actions">
                    <button class="scan-btn" data-section="designsystem">Scan</button>
                    <button class="remove-btn" data-section="designsystem">Remove</button>
                  </div>
                ` : ''}
              </div>
              <div class="section-content" id="designsystem-content">
                <div class="empty-state">
                  <span class="empty-icon">🎭</span>
                  <p>No design system detected</p>
                  <small>Colors, typography, and spacing patterns</small>
                </div>
              </div>
            </div>

            <!-- Custom Context Section -->
            <div class="context-section" data-section="custom">
              <div class="section-header">
                <div class="section-header-left">
                  <h4 class="section-title">✏️ Custom Context</h4>
                  <div class="section-status" id="custom-status">
                    <span class="status-indicator">⚪</span>
                    <span class="status-text">Empty</span>
                  </div>
                </div>
                ${this.options.enableEditing ? `
                  <div class="section-actions">
                    <button class="add-btn" data-section="custom">Add</button>
                    <button class="clear-btn" data-section="custom">Clear</button>
                  </div>
                ` : ''}
              </div>
              <div class="section-content" id="custom-content">
                <div class="empty-state">
                  <span class="empty-icon">📋</span>
                  <p>Add custom context or requirements</p>
                  <small>Business rules, constraints, or specific requirements</small>
                </div>
              </div>
            </div>
          </div>

          ${this.options.showAdvancedMetrics ? `
            <!-- Context Metrics -->
            <div class="context-metrics">
              <h4 class="metrics-title">📊 Context Quality Metrics</h4>
              <div class="metrics-grid">
                <div class="metric-item">
                  <div class="metric-label">Context Richness</div>
                  <div class="metric-value" id="richness-score">0%</div>
                  <div class="metric-bar">
                    <div class="metric-fill" id="richness-fill"></div>
                  </div>
                </div>
                <div class="metric-item">
                  <div class="metric-label">Token Count</div>
                  <div class="metric-value" id="token-count">0</div>
                  <div class="metric-detail">~0 words</div>
                </div>
                <div class="metric-item">
                  <div class="metric-label">Context Size</div>
                  <div class="metric-value" id="context-size">0 KB</div>
                  <div class="metric-detail">Including images</div>
                </div>
                <div class="metric-item">
                  <div class="metric-label">Confidence</div>
                  <div class="metric-value" id="confidence-score">0%</div>
                  <div class="metric-detail">Analysis quality</div>
                </div>
              </div>
            </div>
          ` : ''}

          <!-- Context Summary -->
          <div class="context-summary">
            <h4 class="summary-title">📝 Context Summary</h4>
            <div class="summary-content" id="context-summary">
              <p class="summary-text">No context data to summarize</p>
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="context-actions">
            <button class="action-btn secondary" id="edit-context-btn">
              ✏️ Edit Context
            </button>
            <button class="action-btn secondary" id="optimize-context-btn">
              ⚡ Optimize Context
            </button>
            <button class="action-btn primary" id="submit-context-btn" disabled>
              🚀 Generate with Context
            </button>
          </div>
        </div>
      </div>
    `;

    this.addStyles();
  }

  addStyles() {
    if (document.getElementById('context-preview-styles')) return;

    const styles = document.createElement('style');
    styles.id = 'context-preview-styles';
    styles.textContent = `
      .context-preview-container {
        margin: 20px 0;
      }

      .context-preview {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
      }

      .context-preview-header {
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        padding: 16px 20px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
      }

      .context-preview-title {
        margin: 0 0 4px 0;
        font-size: 16px;
        font-weight: 600;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .context-preview-badge {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-size: 10px;
        font-weight: 500;
        padding: 2px 6px;
        border-radius: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .context-preview-subtitle {
        margin: 0;
        font-size: 13px;
        color: #64748b;
      }

      .collapse-btn {
        background: none;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        padding: 6px 10px;
        cursor: pointer;
        color: #64748b;
        font-size: 12px;
        transition: all 0.2s ease;
      }

      .collapse-btn:hover {
        background: #f1f5f9;
        border-color: #94a3b8;
      }

      .collapse-icon {
        transition: transform 0.2s ease;
      }

      .context-preview.collapsed .collapse-icon {
        transform: rotate(-90deg);
      }

      .context-preview.collapsed .context-preview-body {
        display: none;
      }

      .context-preview-body {
        padding: 20px;
      }

      .context-sections {
        display: grid;
        gap: 16px;
        margin-bottom: 24px;
      }

      .context-section {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow: hidden;
        transition: all 0.2s ease;
      }

      .context-section:hover {
        border-color: #cbd5e1;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
      }

      .context-section.has-content {
        border-color: #10b981;
        background: #f0fdf4;
      }

      .context-section.has-content .section-header {
        background: #ecfdf5;
        border-bottom-color: #a7f3d0;
      }

      .section-header {
        background: #f8fafc;
        padding: 12px 16px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .section-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .section-title {
        margin: 0;
        font-size: 14px;
        font-weight: 600;
        color: #374151;
      }

      .section-status {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
      }

      .status-indicator {
        font-size: 8px;
      }

      .status-text {
        color: #6b7280;
      }

      .section-actions {
        display: flex;
        gap: 8px;
      }

      .section-actions button {
        background: none;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        padding: 4px 8px;
        font-size: 11px;
        cursor: pointer;
        color: #6b7280;
        transition: all 0.2s ease;
      }

      .section-actions button:hover {
        background: #f9fafb;
        border-color: #9ca3af;
        color: #374151;
      }

      .edit-btn:hover { border-color: #3b82f6; color: #3b82f6; }
      .remove-btn:hover { border-color: #ef4444; color: #ef4444; }
      .capture-btn:hover, .scan-btn:hover, .refresh-btn:hover { border-color: #10b981; color: #10b981; }
      .add-btn:hover { border-color: #8b5cf6; color: #8b5cf6; }

      .section-content {
        padding: 16px;
      }

      .empty-state {
        text-align: center;
        padding: 20px;
        color: #9ca3af;
      }

      .empty-icon {
        font-size: 24px;
        display: block;
        margin-bottom: 8px;
      }

      .empty-state p {
        margin: 0 0 4px 0;
        font-size: 14px;
        color: #6b7280;
      }

      .empty-state small {
        font-size: 12px;
        color: #9ca3af;
      }

      .context-metrics {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 20px;
      }

      .metrics-title {
        margin: 0 0 16px 0;
        font-size: 14px;
        font-weight: 600;
        color: #374151;
      }

      .metrics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 16px;
      }

      .metric-item {
        text-align: center;
      }

      .metric-label {
        font-size: 12px;
        color: #6b7280;
        margin-bottom: 4px;
      }

      .metric-value {
        font-size: 18px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 4px;
      }

      .metric-detail {
        font-size: 10px;
        color: #9ca3af;
      }

      .metric-bar {
        width: 100%;
        height: 4px;
        background: #e5e7eb;
        border-radius: 2px;
        overflow: hidden;
        margin-top: 8px;
      }

      .metric-fill {
        height: 100%;
        background: linear-gradient(90deg, #ef4444 0%, #f59e0b 50%, #10b981 100%);
        width: 0%;
        transition: width 0.5s ease;
      }

      .context-summary {
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 20px;
      }

      .summary-title {
        margin: 0 0 12px 0;
        font-size: 14px;
        font-weight: 600;
        color: #374151;
      }

      .summary-content {
        font-size: 13px;
        line-height: 1.5;
        color: #4b5563;
      }

      .summary-text {
        margin: 0;
      }

      .context-actions {
        display: flex;
        gap: 12px;
        justify-content: flex-end;
        flex-wrap: wrap;
      }

      .action-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .action-btn.primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
      }

      .action-btn.primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
      }

      .action-btn.primary:disabled {
        background: #94a3b8;
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
      }

      .action-btn.secondary {
        background: #f8fafc;
        color: #374151;
        border: 1px solid #e2e8f0;
      }

      .action-btn.secondary:hover {
        background: #f1f5f9;
        border-color: #cbd5e1;
      }

      /* Content display styles */
      .tech-stack-analysis {
        font-size: 13px;
        line-height: 1.5;
      }

      .detected-frameworks {
        margin-bottom: 12px;
      }

      .framework-tag {
        display: inline-block;
        background: #dbeafe;
        color: #1e40af;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 11px;
        margin: 2px 4px 2px 0;
      }

      .confidence-display {
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        border-radius: 6px;
        padding: 8px 12px;
        margin-top: 8px;
        font-size: 12px;
        color: #166534;
      }

      .screenshot-display {
        text-align: center;
      }

      .screenshot-image {
        max-width: 100%;
        max-height: 200px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        margin-bottom: 8px;
      }

      .screenshot-info {
        font-size: 12px;
        color: #6b7280;
      }

      .mcp-data-display {
        font-size: 13px;
      }

      .mcp-tools {
        margin-bottom: 12px;
      }

      .tool-item {
        display: flex;
        justify-content: space-between;
        padding: 6px 0;
        border-bottom: 1px solid #f1f5f9;
      }

      .tool-name {
        font-weight: 500;
        color: #374151;
      }

      .tool-status {
        font-size: 11px;
        color: #10b981;
      }

      @media (max-width: 768px) {
        .context-preview-header {
          flex-direction: column;
          gap: 12px;
          align-items: flex-start;
        }

        .metrics-grid {
          grid-template-columns: repeat(2, 1fr);
        }

        .context-actions {
          flex-direction: column;
        }

        .action-btn {
          width: 100%;
          justify-content: center;
        }
      }
    `;

    document.head.appendChild(styles);
  }

  bindEvents() {
    // Collapse/expand functionality
    const collapseBtn = this.container.querySelector('.collapse-btn');
    if (collapseBtn) {
      collapseBtn.addEventListener('click', () => {
        this.container.querySelector('.context-preview').classList.toggle('collapsed');
      });
    }

    // Section action buttons
    this.container.addEventListener('click', (e) => {
      const target = e.target;
      const section = target.dataset.section;

      if (target.classList.contains('edit-btn')) {
        this.editSection(section);
      } else if (target.classList.contains('remove-btn')) {
        this.removeSection(section);
      } else if (target.classList.contains('capture-btn')) {
        this.captureScreenshot();
      } else if (target.classList.contains('scan-btn')) {
        this.scanDesignSystem();
      } else if (target.classList.contains('refresh-btn')) {
        this.refreshMCPData();
      } else if (target.classList.contains('add-btn')) {
        this.addCustomContext();
      } else if (target.classList.contains('clear-btn')) {
        this.clearSection(section);
      }
    });

    // Main action buttons
    const editBtn = this.container.querySelector('#edit-context-btn');
    const optimizeBtn = this.container.querySelector('#optimize-context-btn');
    const submitBtn = this.container.querySelector('#submit-context-btn');

    if (editBtn) editBtn.addEventListener('click', () => this.editAllContext());
    if (optimizeBtn) optimizeBtn.addEventListener('click', () => this.optimizeContext());
    if (submitBtn) submitBtn.addEventListener('click', () => this.submitContext());
  }

  updateContext(contextData) {
    this.contextData = contextData;
    this.renderContextData();
    this.updateMetrics();
    this.updateSummary();
    this.validateContext();
  }

  renderContextData() {
    if (!this.contextData) return;

    // Update tech stack section
    if (this.contextData.techStack) {
      this.updateTechStackSection(this.contextData.techStack);
    }

    // Update screenshot section
    if (this.contextData.screenshot) {
      this.updateScreenshotSection(this.contextData.screenshot);
    }

    // Update MCP data section
    if (this.contextData.mcpData) {
      this.updateMCPDataSection(this.contextData.mcpData);
    }

    // Update design system section
    if (this.contextData.designSystem) {
      this.updateDesignSystemSection(this.contextData.designSystem);
    }

    // Update custom context section
    if (this.contextData.customContext) {
      this.updateCustomContextSection(this.contextData.customContext);
    }
  }

  updateTechStackSection(techStackData) {
    const section = this.container.querySelector('[data-section="techstack"]');
    const status = section.querySelector('#techstack-status');
    const content = section.querySelector('#techstack-content');

    section.classList.add('has-content');
    
    status.innerHTML = `
      <span class="status-indicator">✅</span>
      <span class="status-text">Analyzed (${techStackData.confidence}% confidence)</span>
    `;

    content.innerHTML = `
      <div class="tech-stack-analysis">
        <div class="detected-frameworks">
          <strong>Detected Technologies:</strong><br>
          ${techStackData.detected.frameworks.map(f => 
            `<span class="framework-tag">${f}</span>`
          ).join('')}
          ${techStackData.detected.languages.map(l => 
            `<span class="framework-tag">${l}</span>`
          ).join('')}
        </div>
        <div class="confidence-display">
          📊 Analysis Confidence: ${techStackData.confidence}%
        </div>
        ${techStackData.designContext ? `
          <div style="margin-top: 12px; font-size: 12px; color: #6b7280;">
            <strong>Design Patterns:</strong> ${techStackData.designContext.patterns?.length || 0} detected<br>
            <strong>Components:</strong> ${techStackData.designContext.components?.length || 0} identified
          </div>
        ` : ''}
      </div>
    `;
  }

  updateScreenshotSection(screenshotData) {
    const section = this.container.querySelector('[data-section="screenshot"]');
    const status = section.querySelector('#screenshot-status');
    const content = section.querySelector('#screenshot-content');

    section.classList.add('has-content');
    
    status.innerHTML = `
      <span class="status-indicator">📸</span>
      <span class="status-text">Captured (${screenshotData.size || 'Unknown size'})</span>
    `;

    content.innerHTML = `
      <div class="screenshot-display">
        <img src="${screenshotData.dataUrl}" alt="Design Screenshot" class="screenshot-image">
        <div class="screenshot-info">
          ${screenshotData.width}×${screenshotData.height}px • ${screenshotData.size || 'Unknown size'}
        </div>
      </div>
    `;
  }

  updateMCPDataSection(mcpData) {
    const section = this.container.querySelector('[data-section="mcpdata"]');
    const status = section.querySelector('#mcpdata-status');
    const content = section.querySelector('#mcpdata-content');

    section.classList.add('has-content');
    
    status.innerHTML = `
      <span class="status-indicator">🔗</span>
      <span class="status-text">Connected (${mcpData.tools?.length || 0} tools)</span>
    `;

    content.innerHTML = `
      <div class="mcp-data-display">
        <div class="mcp-tools">
          <strong>Available Tools:</strong><br>
          ${mcpData.tools?.map(tool => `
            <div class="tool-item">
              <span class="tool-name">${tool.name}</span>
              <span class="tool-status">✅ Available</span>
            </div>
          `).join('') || '<div style="color: #9ca3af;">No tools available</div>'}
        </div>
      </div>
    `;
  }

  updateDesignSystemSection(designSystemData) {
    const section = this.container.querySelector('[data-section="designsystem"]');
    const status = section.querySelector('#designsystem-status');
    const content = section.querySelector('#designsystem-content');

    section.classList.add('has-content');
    
    status.innerHTML = `
      <span class="status-indicator">🎨</span>
      <span class="status-text">Detected (${designSystemData.tokensCount || 0} tokens)</span>
    `;

    content.innerHTML = `
      <div class="design-system-display">
        <div style="font-size: 13px;">
          <div><strong>Colors:</strong> ${designSystemData.colors?.length || 0} detected</div>
          <div><strong>Typography:</strong> ${designSystemData.typography?.length || 0} styles</div>
          <div><strong>Spacing:</strong> ${designSystemData.spacing?.length || 0} patterns</div>
        </div>
      </div>
    `;
  }

  updateCustomContextSection(customData) {
    const section = this.container.querySelector('[data-section="custom"]');
    const status = section.querySelector('#custom-status');
    const content = section.querySelector('#custom-content');

    section.classList.add('has-content');
    
    status.innerHTML = `
      <span class="status-indicator">✏️</span>
      <span class="status-text">${customData.items?.length || 0} items</span>
    `;

    content.innerHTML = `
      <div class="custom-context-display">
        ${customData.items?.map(item => `
          <div style="padding: 8px; background: #f8fafc; border-radius: 4px; margin-bottom: 8px; font-size: 13px;">
            ${item}
          </div>
        `).join('') || '<div style="color: #9ca3af;">No custom context added</div>'}
      </div>
    `;
  }

  updateMetrics() {
    if (!this.options.showAdvancedMetrics || !this.contextData) return;

    const richness = this.calculateRichness();
    const tokenCount = this.calculateTokenCount();
    const contextSize = this.calculateContextSize();
    const confidence = this.contextData.techStack?.confidence || 0;

    // Update metric displays
    const richnessScore = this.container.querySelector('#richness-score');
    const richnessFill = this.container.querySelector('#richness-fill');
    const tokenCountEl = this.container.querySelector('#token-count');
    const contextSizeEl = this.container.querySelector('#context-size');
    const confidenceScoreEl = this.container.querySelector('#confidence-score');

    if (richnessScore) richnessScore.textContent = `${richness}%`;
    if (richnessFill) richnessFill.style.width = `${richness}%`;
    if (tokenCountEl) tokenCountEl.textContent = tokenCount.toLocaleString();
    if (contextSizeEl) contextSizeEl.textContent = `${contextSize} KB`;
    if (confidenceScoreEl) confidenceScoreEl.textContent = `${confidence}%`;
  }

  calculateRichness() {
    if (!this.contextData) return 0;
    
    let score = 0;
    if (this.contextData.techStack) score += 25;
    if (this.contextData.screenshot) score += 30;
    if (this.contextData.mcpData) score += 25;
    if (this.contextData.designSystem) score += 15;
    if (this.contextData.customContext?.items?.length > 0) score += 5;
    
    return Math.min(score, 100);
  }

  calculateTokenCount() {
    if (!this.contextData) return 0;
    
    let count = 0;
    if (this.contextData.techStack) count += 200;
    if (this.contextData.screenshot) count += 100;
    if (this.contextData.mcpData) count += 150;
    if (this.contextData.designSystem) count += 100;
    if (this.contextData.customContext) count += 50;
    
    return count;
  }

  calculateContextSize() {
    if (!this.contextData) return 0;
    
    let size = 0;
    if (this.contextData.techStack) size += 1;
    if (this.contextData.screenshot) size += 15; // Screenshot is larger
    if (this.contextData.mcpData) size += 2;
    if (this.contextData.designSystem) size += 1;
    if (this.contextData.customContext) size += 0.5;
    
    return Math.round(size * 10) / 10;
  }

  updateSummary() {
    const summaryContent = this.container.querySelector('#context-summary');
    if (!summaryContent || !this.contextData) return;

    const sections = [];
    if (this.contextData.techStack) sections.push('tech stack analysis');
    if (this.contextData.screenshot) sections.push('visual design screenshot');
    if (this.contextData.mcpData) sections.push('MCP server data');
    if (this.contextData.designSystem) sections.push('design system tokens');
    if (this.contextData.customContext?.items?.length > 0) sections.push('custom requirements');

    const summary = sections.length > 0 
      ? `Ready to generate with ${sections.join(', ')}. Context richness: ${this.calculateRichness()}%`
      : 'No context data available. Add tech stack, screenshots, or other context to improve results.';

    summaryContent.innerHTML = `<p class="summary-text">${summary}</p>`;
  }

  validateContext() {
    const submitBtn = this.container.querySelector('#submit-context-btn');
    if (!submitBtn) return;

    const hasMinimumContext = this.contextData && (
      this.contextData.techStack || 
      this.contextData.screenshot || 
      this.contextData.mcpData
    );

    submitBtn.disabled = !hasMinimumContext;
  }

  // Action methods
  editSection(section) {
    console.log(`Edit section: ${section}`);
    // Implement section-specific editing
  }

  removeSection(section) {
    console.log(`Remove section: ${section}`);
    if (this.contextData && this.contextData[section]) {
      delete this.contextData[section];
      this.updateContext(this.contextData);
      this.onDataChange(this.contextData);
    }
  }

  captureScreenshot() {
    console.log('Capture screenshot');
    // Implement screenshot capture
  }

  scanDesignSystem() {
    console.log('Scan design system');
    // Implement design system scanning
  }

  refreshMCPData() {
    console.log('Refresh MCP data');
    // Implement MCP data refresh
  }

  addCustomContext() {
    console.log('Add custom context');
    const input = prompt('Enter custom context or requirement:');
    if (input && input.trim()) {
      if (!this.contextData.customContext) {
        this.contextData.customContext = { items: [] };
      }
      this.contextData.customContext.items.push(input.trim());
      this.updateContext(this.contextData);
      this.onDataChange(this.contextData);
    }
  }

  clearSection(section) {
    this.removeSection(section);
  }

  editAllContext() {
    console.log('Edit all context');
    // Implement comprehensive context editing
  }

  optimizeContext() {
    console.log('Optimize context');
    // Implement context optimization suggestions
  }

  submitContext() {
    console.log('Submit context');
    this.onSubmit(this.contextData);
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ContextPreview;
}

// Global registration for direct HTML usage
if (typeof window !== 'undefined') {
  window.ContextPreview = ContextPreview;
}