/**
 * Ticket Generator functionality
 * Handles AI-powered ticket generation from Figma frames
 */

// State management
let frameDataList = [];
let isGenerating = false;
let hasGeneratedTicket = false; // Track if ticket was generated for current selection
let currentSelectionHash = ''; // Hash of current selection to detect changes
let globalFileKey = '';
let globalFileName = '';

/**
 * Initialize ticket generator
 */
function initializeTicketGenerator() {
  if (!elements.generateBtn) return;
  
  // Event listeners
  elements.generateBtn.onclick = generateTicket;
  elements.copyBtn.onclick = handleCopyToClipboard;
  elements.apiKeyInput.onchange = saveSettings;
  elements.modelSelect.onchange = saveSettings;
  elements.templateSelect.onchange = saveSettings;
  
  // Load saved settings
  loadSettings();
  
  console.log('🎫 Ticket Generator initialized');
}

/**
 * Generate ticket from selected frames
 */
function generateTicket() {
  if (isGenerating) return;
  
  // Check if ticket was already generated for current selection
  if (hasGeneratedTicket && currentSelectionHash) {
    showStatus('Ticket already generated for this selection. Change selection to generate a new ticket.', 'error');
    return;
  }

  setGenerating(true);
  showStatus('Reading selected frames...', 'loading');
  
  // Request frame data from Figma
  sendToPlugin({ type: 'generate-ticket' });
}

/**
 * Handle frame data received from plugin
 * @param {Array} data - Frame data array
 */
function handleFrameData(data) {
  frameDataList = data;
  
  // Create hash of current selection to detect changes
  const newSelectionHash = createSelectionHash(data);
  
  // Check if selection changed - reset ticket generation state
  if (newSelectionHash !== currentSelectionHash) {
    currentSelectionHash = newSelectionHash;
    hasGeneratedTicket = false;
    resetGenerateButton();
    elements.output.value = ''; // Clear previous output
    elements.copyBtn.disabled = true;
  }
  
  displayFrameInfo(frameDataList);
  displayComplianceInfo(frameDataList);
  generateAITicket();
}

/**
 * Generate AI ticket using MCP server with fallback
 */
async function generateAITicket() {
  if (!frameDataList.length) {
    showStatus('No frame data received', 'error');
    setGenerating(false);
    return;
  }

  console.log('🚀 Starting enhanced ticket generation...');

  try {
    showStatus('🔍 Analyzing project with MCP...', 'loading');
    
    // Try MCP server first
    const mcpTickets = await callMCPServer('generate_tickets', {
      frameData: frameDataList,
      template: elements.templateSelect.value,
      projectName: globalFileName || 'Figma Design'
    });
    
    showStatus('🎫 Processing MCP results...', 'loading');
    console.log('📦 MCP response received:', mcpTickets);
    
    // If MCP server is available, use the enhanced tickets
    if (mcpTickets && mcpTickets.content && mcpTickets.content.length > 0) {
      const ticketText = mcpTickets.content[0].text;
      
      elements.output.value = ticketText;
      elements.copyBtn.disabled = false;
      hasGeneratedTicket = true;
      setGeneratingComplete();
      showStatus('✅ Enhanced tickets generated with MCP!', 'success');
      return;
    }
    
    // Fallback ticket generation (no API key required)
    console.log('🔄 MCP failed, generating fallback ticket');
    
    const fallbackTicket = `# Generated Ticket (Fallback)

## ${frameDataList[0]?.name || 'Component'} Implementation

### Description
Implement the ${frameDataList[0]?.name || 'selected component'} based on Figma design specifications.

### Acceptance Criteria
- [ ] Component matches design specifications
- [ ] Component is responsive across all devices  
- [ ] Component passes accessibility testing
- [ ] Unit tests provide adequate coverage

### Technical Notes
- Based on ${frameDataList.length} selected frame(s)
- Generated with local fallback (MCP server unavailable)
- Node count: ${frameDataList[0]?.nodeCount || 'Unknown'}
- Dimensions: ${frameDataList[0]?.dimensions?.width || 0}x${frameDataList[0]?.dimensions?.height || 0}px

### Priority
Medium

### Story Points
${Math.max(3, Math.min(8, Math.ceil((frameDataList[0]?.nodeCount || 0) / 5)))}

---
*Generated at ${new Date().toISOString()}*`;
    
    elements.output.value = fallbackTicket;
    elements.copyBtn.disabled = false;
    hasGeneratedTicket = true;
    setGeneratingComplete();
    showStatus('⚠️ Fallback ticket generated (MCP server unavailable)', 'error');
    
  } catch (error) {
    console.error('❌ Error in ticket generation:', error);
    
    // Final fallback
    const simpleTicket = `# Simple Ticket

## Component Implementation

### Description  
Implement the selected component based on Figma design.

### Acceptance Criteria
- [ ] Match design specifications
- [ ] Ensure responsiveness
- [ ] Pass accessibility tests

---
*Generated at ${new Date().toISOString()}*`;
    
    elements.output.value = simpleTicket;
    elements.copyBtn.disabled = false;
    hasGeneratedTicket = true;
    setGeneratingComplete();
    showStatus('⚠️ Simple ticket generated (errors occurred)', 'error');
  } finally {
    setGenerating(false);
  }
}

/**
 * Call MCP Server for enhanced ticket generation
 */
async function callMCPServer(method, params) {
  try {
    console.log('🔍 Calling MCP server:', method, params);
    
    const response = await fetch('http://localhost:3000', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        method: method,
        params: params
      }),
    });
    
    console.log('📡 MCP response status:', response.status);
    
    if (!response.ok) {
      throw new Error(`MCP Server error: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('📦 MCP response data:', data);
    return data.result || data;
  } catch (error) {
    console.warn('MCP Server not available:', error);
    return null;
  }
}

/**
 * Create prompt for AI ticket generation
 * @param {Array} frameDataList - Array of frame data
 * @returns {string} Generated prompt
 */
function createPrompt(frameDataList) {
  const template = elements.templateSelect.value;
  const customInstructions = elements.customPromptInput.value.trim();
  
  let basePrompt = '';
  
  switch (template) {
    case 'component':
      basePrompt = 'Generate a Jira ticket for implementing a UI component based on the following Figma design:';
      break;
    case 'feature':
      basePrompt = 'Generate a Jira ticket for implementing a new feature based on the following Figma design:';
      break;
    case 'bug':
      basePrompt = 'Generate a Jira ticket for fixing a UI/UX issue based on the following Figma design:';
      break;
    case 'page':
      basePrompt = 'Generate a Jira ticket for implementing a page/screen based on the following Figma design:';
      break;
    default:
      basePrompt = 'Generate a Jira ticket based on the following Figma design:';
  }

  let prompt = basePrompt + '\\n\\n';

  frameDataList.forEach((frame, index) => {
    prompt += `**Frame ${index + 1}: ${frame.name}**\\n`;
    prompt += `- Page: ${frame.pageName}\\n`;
    prompt += `- Type: ${frame.type}\\n`;
    prompt += `- Dimensions: ${frame.dimensions.width}x${frame.dimensions.height}px\\n`;
    prompt += `- Child elements: ${frame.nodeCount}\\n`;
    
    if (frame.textContent.length > 0) {
      prompt += `- Text content: ${frame.textContent.map(t => `"${t.content}"`).join(', ')}\\n`;
    }
    
    if (frame.components.length > 0) {
      prompt += `- Components used: ${frame.components.map(c => c.name || c.componentName || 'Unknown Component').join(', ')}\\n`;
    }
    
    if (frame.colors.length > 0) {
      prompt += `- Colors: ${frame.colors.join(', ')}\\n`;
    }
    
    if (frame.hasPrototype) {
      prompt += `- Has interactive prototype\\n`;
    }

    // Add design system context if available
    if (frame.designSystemContext) {
      const context = frame.designSystemContext;
      
      if (context.designSystem) {
        prompt += `\\n**Design System Information:**\\n`;
        prompt += `- Design System: ${context.designSystem.name}\\n`;
        prompt += `- Detection Confidence: ${Math.round(context.designSystem.detectionConfidence * 100)}%\\n`;
      }

      if (context.complianceReport) {
        const report = context.complianceReport;
        prompt += `\\n**Design System Compliance:**\\n`;
        prompt += `- Overall Score: ${report.overallScore}%\\n`;
        prompt += `- Color Compliance: ${report.colorCompliance.score}% (${report.colorCompliance.tokenizedColors}/${report.colorCompliance.totalColors} using tokens)\\n`;
        prompt += `- Typography Compliance: ${report.typographyCompliance.score}% (${report.typographyCompliance.tokenizedText}/${report.typographyCompliance.totalTextElements} using styles)\\n`;
        prompt += `- Component Compliance: ${report.componentCompliance.score}% (${report.componentCompliance.standardComponents}/${report.componentCompliance.totalComponents} standard components)\\n`;
      }

      if (context.usedTokens && context.usedTokens.length > 0) {
        prompt += `\\n**Design Tokens Used:**\\n`;
        context.usedTokens.forEach(token => {
          prompt += `- ${token.name} (${token.type})\\n`;
        });
      }

      if (context.violations && context.violations.length > 0) {
        prompt += `\\n**Design System Violations:**\\n`;
        context.violations.forEach(violation => {
          prompt += `- ${violation.description}\\n`;
          prompt += `  Suggested Fix: ${violation.suggestedFix}\\n`;
        });
      }

      if (context.recommendations && context.recommendations.length > 0) {
        prompt += `\\n**Design System Recommendations:**\\n`;
        context.recommendations.slice(0, 3).forEach(rec => { // Limit to top 3
          prompt += `- [${rec.severity.toUpperCase()}] ${rec.message}\\n`;
          prompt += `  Suggestion: ${rec.suggestion}\\n`;
        });
      }
    }
    
    // Create proper Figma deep link
    const fileKey = frame.fileKey || globalFileKey || '';
    const nodeId = frame.id.replace(':', '-'); // Convert colon to hyphen format
    const fileName = globalFileName ? `/${encodeURIComponent(globalFileName)}` : '';
    const figmaLink = `https://www.figma.com/design/${fileKey}${fileName}?node-id=${nodeId}&t=${Date.now()}`;
    prompt += `\\n- Figma link: ${figmaLink}\\n`;
    prompt += `- Frame ID: ${frame.id} (for developer reference)\\n\\n`;
  });

  if (customInstructions) {
    prompt += `**Additional Requirements:**\\n${customInstructions}\\n\\n`;
  }

  prompt += `Please format the response as:\\n\\n`;
  prompt += `**Title:** [Concise ticket title]\\n\\n`;
  prompt += `**Description:**\\n[Detailed description with context and requirements]\\n\\n`;
  prompt += `**Figma Reference:**\\n[Include the Figma link and frame details for easy access]\\n\\n`;
  prompt += `**Acceptance Criteria:**\\n1. [Specific, testable criteria]\\n2. [Another criteria]\\n3. [etc.]\\n\\n`;
  prompt += `**Technical Notes:**\\n[Any implementation details, dependencies, or considerations]\\n\\n`;
  prompt += `**Design Specs:**\\n[Key measurements, colors, fonts, and visual requirements from the Figma frame]\\n\\n`;
  
  // Add design system specific instructions if we have design system data
  const hasDesignSystemData = frameDataList.some(frame => frame.designSystemContext);
  if (hasDesignSystemData) {
    prompt += `**Design System Compliance:**\\n[Address any violations mentioned above and ensure implementation follows the design system standards. Reference specific tokens and components where applicable.]\\n\\n`;
    prompt += `**Design System Notes:**\\n[Include specific design token names, component variants, and compliance recommendations to maintain consistency with the established design system.]`;
  }

  return prompt;
}

/**
 * Display frame information
 * @param {Array} frameDataList - Array of frame data
 */
function displayFrameInfo(frameDataList) {
  if (!frameDataList.length) {
    elements.frameInfoDiv.classList.add('hidden');
    return;
  }

  let html = '';
  frameDataList.forEach((frame, index) => {
    html += `
      <div class="frame-info">
        <div class="frame-name">${frame.name}</div>
        <div class="frame-details">
          ${frame.type} • ${frame.dimensions.width}x${frame.dimensions.height}px • ${frame.nodeCount} elements
        </div>
      </div>
    `;
  });

  elements.frameInfoDiv.innerHTML = html;
  elements.frameInfoDiv.classList.remove('hidden');
}

/**
 * Display compliance information for ticket panel
 * @param {Array} frameDataList - Array of frame data
 */
function displayComplianceInfo(frameDataList) {
  if (!elements.complianceInfo) return;
  
  // Find frames with design system context
  const framesWithContext = frameDataList.filter(frame => 
    frame.designSystemContext && frame.designSystemContext.complianceReport
  );

  if (framesWithContext.length === 0) {
    elements.complianceInfo.classList.add('hidden');
    return;
  }

  // Calculate average scores
  let totalOverall = 0;
  let totalColor = 0;
  let totalTypography = 0;
  let totalComponent = 0;
  let allRecommendations = [];

  framesWithContext.forEach(frame => {
    const report = frame.designSystemContext.complianceReport;
    totalOverall += report.overallScore;
    totalColor += report.colorCompliance.score;
    totalTypography += report.typographyCompliance.score;
    totalComponent += report.componentCompliance.score;
    allRecommendations = allRecommendations.concat(report.recommendations);
  });

  const count = framesWithContext.length;
  const avgOverall = Math.round(totalOverall / count);
  const avgColor = Math.round(totalColor / count);
  const avgTypography = Math.round(totalTypography / count);
  const avgComponent = Math.round(totalComponent / count);

  if (elements.complianceScore) {
    elements.complianceScore.textContent = `${avgOverall}%`;
    elements.complianceScore.style.background = getScoreColor(avgOverall);
  }
  
  if (elements.colorScore) {
    elements.colorScore.textContent = `${avgColor}%`;
    elements.colorScore.style.background = getScoreColor(avgColor);
  }
  
  if (elements.typographyScore) {
    elements.typographyScore.textContent = `${avgTypography}%`;
    elements.typographyScore.style.background = getScoreColor(avgTypography);
  }
  
  if (elements.componentScore) {
    elements.componentScore.textContent = `${avgComponent}%`;
    elements.componentScore.style.background = getScoreColor(avgComponent);
  }

  // Display recommendations
  if (allRecommendations.length > 0 && elements.recList) {
    let recHtml = '';
    allRecommendations.slice(0, 3).forEach(rec => { // Show max 3 recommendations
      recHtml += `
        <div class="rec-item ${rec.severity}">
          <div class="rec-message">${rec.message}</div>
          <div class="rec-suggestion">${rec.suggestion}</div>
        </div>
      `;
    });
    elements.recList.innerHTML = recHtml;
    elements.recommendations.classList.remove('hidden');
  } else if (elements.recommendations) {
    elements.recommendations.classList.add('hidden');
  }

  elements.complianceInfo.classList.remove('hidden');
}

/**
 * Handle copy to clipboard button click
 */
function handleCopyToClipboard() {
  if (elements.output.value.trim()) {
    copyToClipboard(
      elements.output.value,
      () => showStatus('Copied to clipboard!', 'success'),
      (error) => showStatus(error, 'error')
    );
  }
}

/**
 * Handle file context from plugin
 * @param {string} fileKey - Figma file key
 * @param {string} fileName - Figma file name
 */
function handleFileContext(fileKey, fileName) {
  globalFileKey = fileKey || '';
  globalFileName = fileName || '';
  console.log('📁 File context received:', { fileKey: globalFileKey, fileName: globalFileName });
}

/**
 * Display design system information
 * @param {Object} designSystem - Design system data
 */
function displayDesignSystemInfo(designSystem) {
  if (!elements.designSystemSection) return;

  if (elements.dsName) elements.dsName.textContent = designSystem.name;
  if (elements.dsConfidence) elements.dsConfidence.textContent = `${Math.round(designSystem.detectionConfidence * 100)}%`;
  if (elements.dsColors) elements.dsColors.textContent = `${designSystem.colors.length} colors`;
  if (elements.dsTypography) elements.dsTypography.textContent = `${designSystem.typography.length} text styles`;
  if (elements.dsComponents) elements.dsComponents.textContent = `${designSystem.components.components.length} components`;

  elements.designSystemSection.classList.remove('hidden');
}

/**
 * Hide design system section
 */
function hideDesignSystemSection() {
  if (elements.designSystemSection) {
    elements.designSystemSection.classList.add('hidden');
  }
}

/**
 * Create a hash of the current selection to detect changes
 * @param {Array} frameDataList - Array of frame data
 * @returns {string} Hash representing the selection
 */
function createSelectionHash(frameDataList) {
  if (!frameDataList || frameDataList.length === 0) return '';
  
  // Create a simple hash based on frame IDs and names
  const selectionData = frameDataList.map(frame => `${frame.id}:${frame.name}`).join('|');
  return btoa(selectionData).substr(0, 16); // Simple hash using base64
}

/**
 * Reset generate button to initial state
 */
function resetGenerateButton() {
  if (!elements.generateBtn) return;
  
  elements.generateBtn.disabled = false;
  elements.generateBtn.textContent = '📋 Generate Ticket from Selection';
  elements.generateBtn.style.background = ''; // Reset to default
}

/**
 * Set button to "generated" state
 */
function setGeneratingComplete() {
  if (!elements.generateBtn) return;
  
  elements.generateBtn.disabled = true;
  elements.generateBtn.textContent = '✅ Ticket Generated (Change selection for new ticket)';
  elements.generateBtn.style.background = 'var(--figma-color-bg-success)';
}