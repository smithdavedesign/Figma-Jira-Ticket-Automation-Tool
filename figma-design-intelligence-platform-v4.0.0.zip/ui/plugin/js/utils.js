/**
 * Utility functions for the Figma AI Ticket Generator UI
 */

// UI Elements - Cached for performance
let elements = {};

/**
 * Initialize UI element references
 */
function initializeElements() {
  elements = {
    // Health Metrics Panel
    overallScore: document.getElementById('overallScore'),
    complianceRate: document.getElementById('complianceRate'),
    componentUsage: document.getElementById('componentUsage'),
    tokenAdoption: document.getElementById('tokenAdoption'),
    standardComponents: document.getElementById('standardComponents'),
    customComponents: document.getElementById('customComponents'),
    topComponent: document.getElementById('topComponent'),
    colorTokens: document.getElementById('colorTokens'),
    typographyTokens: document.getElementById('typographyTokens'),
    spacingTokens: document.getElementById('spacingTokens'),
    healthRecommendations: document.getElementById('healthRecommendations'),
    
    // Ticket Panel
    generateBtn: document.getElementById('generate'),
    output: document.getElementById('output'),
    copyBtn: document.getElementById('copy'),
    apiKeyInput: document.getElementById('apiKey'),
    modelSelect: document.getElementById('model'),
    templateSelect: document.getElementById('template'),
    customPromptInput: document.getElementById('customPrompt'),
    statusDiv: document.getElementById('status'),
    frameInfoDiv: document.getElementById('frameInfo'),
    
    // Design System Integration
    designSystemSection: document.getElementById('designSystemSection'),
    dsName: document.getElementById('dsName'),
    dsConfidence: document.getElementById('dsConfidence'),
    dsColors: document.getElementById('dsColors'),
    dsTypography: document.getElementById('dsTypography'),
    dsComponents: document.getElementById('dsComponents'),
    complianceInfo: document.getElementById('complianceInfo'),
    complianceScore: document.getElementById('complianceScore'),
    colorScore: document.getElementById('colorScore'),
    typographyScore: document.getElementById('typographyScore'),
    componentScore: document.getElementById('componentScore'),
    recommendations: document.getElementById('recommendations'),
    recList: document.getElementById('recList')
  };
}

/**
 * Show status message to user
 * @param {string} message - Message to display
 * @param {string} type - Status type: 'loading', 'success', 'error'
 */
function showStatus(message, type) {
  if (!elements.statusDiv) return;
  
  elements.statusDiv.textContent = message;
  elements.statusDiv.className = `status ${type}`;
  elements.statusDiv.classList.remove('hidden');
  
  if (type === 'success') {
    setTimeout(() => {
      elements.statusDiv.classList.add('hidden');
    }, 3000);
  }
}

/**
 * Set generating state for UI
 * @param {boolean} generating - Whether currently generating
 */
function setGenerating(generating) {
  if (!elements.generateBtn) return;
  
  elements.generateBtn.disabled = generating;
  elements.generateBtn.style.background = ''; // Reset background to default
  elements.generateBtn.textContent = generating 
    ? '⏳ Generating...' 
    : '📋 Generate Ticket from Selection';
}

/**
 * Get score class for color coding
 * @param {number} score - Score from 0-100
 * @returns {string} CSS class name
 */
function getScoreClass(score) {
  if (score >= 90) return 'excellent';
  if (score >= 80) return 'good';
  if (score >= 70) return 'medium';
  if (score >= 60) return 'needs-attention';
  return 'poor';
}

/**
 * Get background color for score
 * @param {number} score - Score from 0-100
 * @returns {string} CSS color value
 */
function getScoreColor(score) {
  if (score >= 90) return 'var(--figma-color-bg-success)';
  if (score >= 70) return 'var(--figma-color-bg-warning)';
  return 'var(--figma-color-bg-danger)';
}

/**
 * Check if localStorage is available
 * @returns {boolean} Whether localStorage can be used
 */
function isLocalStorageAvailable() {
  try {
    // Figma plugins run in a sandboxed environment where localStorage may be disabled
    if (typeof localStorage === 'undefined') return false;
    
    const test = '__localStorage_test__';
    localStorage.setItem(test, test);
    localStorage.removeItem(test);
    return true;
  } catch(e) {
    // Expected in Figma plugin environment - silently return false
    return false;
  }
}

/**
 * Save settings to storage
 */
function saveSettings() {
  if (!elements.apiKeyInput || !elements.modelSelect || !elements.templateSelect) return;
  
  const settings = {
    apiKey: elements.apiKeyInput.value,
    model: elements.modelSelect.value,
    template: elements.templateSelect.value
  };
  
  if (isLocalStorageAvailable()) {
    try {
      localStorage.setItem('aiTicketGenerator', JSON.stringify(settings));
    } catch (error) {
      // Fallback to session storage
      window.tempSettings = settings;
    }
  } else {
    // Store in memory for session
    window.tempSettings = settings;
  }
}

/**
 * Load settings from storage
 */
function loadSettings() {
  if (!elements.apiKeyInput || !elements.modelSelect || !elements.templateSelect) return;
  
  if (isLocalStorageAvailable()) {
    try {
      const settings = JSON.parse(localStorage.getItem('aiTicketGenerator') || '{}');
      if (settings.apiKey) elements.apiKeyInput.value = settings.apiKey;
      if (settings.model) elements.modelSelect.value = settings.model;
      if (settings.template) elements.templateSelect.value = settings.template;
      return; // Exit early if localStorage worked
    } catch (error) {
      // Continue to fallback
    }
  }
  
  // Fallback: try session storage
  if (window.tempSettings) {
    const settings = window.tempSettings;
    if (settings.apiKey) elements.apiKeyInput.value = settings.apiKey;
    if (settings.model) elements.modelSelect.value = settings.model;
    if (settings.template) elements.templateSelect.value = settings.template;
  }
}

/**
 * Copy text to clipboard with fallback methods
 * @param {string} text - Text to copy
 * @param {Function} onSuccess - Success callback
 * @param {Function} onError - Error callback
 */
function copyToClipboard(text, onSuccess, onError) {
  // Try modern clipboard API first
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text)
      .then(() => onSuccess && onSuccess())
      .catch(() => fallbackCopyToClipboard(text, onSuccess, onError));
  } else {
    // Use fallback method
    fallbackCopyToClipboard(text, onSuccess, onError);
  }
}

/**
 * Fallback clipboard copy method
 * @param {string} text - Text to copy
 * @param {Function} onSuccess - Success callback
 * @param {Function} onError - Error callback
 */
function fallbackCopyToClipboard(text, onSuccess, onError) {
  try {
    // Create a temporary textarea element
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    
    // Select and copy the text
    textArea.focus();
    textArea.select();
    
    // Try the legacy execCommand
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    
    if (successful) {
      onSuccess && onSuccess();
    } else {
      // If all else fails, select the text for manual copying
      if (elements.output) {
        elements.output.select();
        elements.output.setSelectionRange(0, 99999); // For mobile devices
      }
      onError && onError('Text selected - press Ctrl+C (or Cmd+C) to copy');
    }
  } catch (error) {
    // Final fallback - just select the text
    if (elements.output) {
      elements.output.select();
      elements.output.setSelectionRange(0, 99999);
    }
    onError && onError('Text selected - press Ctrl+C (or Cmd+C) to copy');
  }
}

/**
 * Send message to Figma plugin
 * @param {Object} message - Message to send
 */
function sendToPlugin(message) {
  parent.postMessage({ pluginMessage: message }, '*');
}

/**
 * Throttle function calls
 * @param {Function} func - Function to throttle
 * @param {number} limit - Time limit in milliseconds
 * @returns {Function} Throttled function
 */
function throttle(func, limit) {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  }
}

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeElements);
} else {
  initializeElements();
}